from bertopic._bertopic import BERTopic

__version__ = "0.15.0"

__all__ = [
    "BERTopic",
]
